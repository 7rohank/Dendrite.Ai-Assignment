#!/usr/bin/env python
# coding: utf-8

# In[2]:


import json
import re
import pandas as pd
import numpy as np
from striprtf.striprtf import rtf_to_text
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer
from sklearn.decomposition import PCA
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, r2_score


# In[41]:


from sklearn.preprocessing import LabelEncoder, StandardScaler, OneHotEncoder
from sklearn.compose import ColumnTransformer
from sklearn.model_selection import GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.svm import SVC, SVR
from sklearn.tree import DecisionTreeClassifier, DecisionTreeRegressor
from sklearn.linear_model import LinearRegressio


# In[3]:


iris_data=pd.read_csv(r"C:\Users\Rohan\Downloads\DS_Assignment - internship\Screening Test - DS\iris.csv")

print(iris_data.head)


# In[4]:


with open(r"C:\Users\Rohan\Downloads\DS_Assignment - internship\Screening Test - DS\algoparams_from_ui.json.rtf", 'r') as file:
    rtf_content = file.read()

plain_text = rtf_to_text(rtf_content)

print(plain_text)


# In[6]:


config = json.loads(plain_text) 


# In[7]:


print(config)


# In[10]:


#Q1)Type of regression 
target_column = config["design_state_data"]["target"]

print(target_column)


# In[11]:


target_column = config["design_state_data"]["target"]["target"]
prediction_type = config["design_state_data"]["target"]["prediction_type"]

print(target_column, prediction_type)


# In[12]:


print(iris_data.columns)


# In[27]:


X = iris_data.drop(columns=['petal_width'])
y = iris_data['petal_width']


# In[16]:


#Q2)Missing imputation 

feature_handling = config["design_state_data"]["feature_handling"]

preprocessing_steps = []
for feature, details in feature_handling.items():
    if details["is_selected"]:
        if details["feature_variable_type"] == "numerical":
            impute_strategy = "mean" if details["feature_details"]["impute_with"] == "Average of values" else "constant"
            preprocessing_steps.append((
                feature,
                SimpleImputer(strategy=impute_strategy, fill_value=details["feature_details"]["impute_value"]),
            ))
            
print(feature_handling)            


# In[18]:


#Q3)Feature reduction 

feature_reduction = config["design_state_data"]["feature_reduction"]
if feature_reduction["feature_reduction_method"] == "PCA":
    preprocessing_steps.append(("pca", PCA(n_components=int(feature_reduction["num_of_features_to_keep"]))))

print(feature_reduction)


# In[22]:


#Q4)Prediction_type

model_config = config["design_state_data"]["algorithms"]
prediction_type = config["design_state_data"]["target"]["prediction_type"]

selected_model = None
model = None

for model_name, model_details in model_config.items():
    if model_details["is_selected"]:
        selected_model = model_name
        break

if prediction_type == "classification":
    if selected_model == "LogisticRegression":
        model = LogisticRegression(
            C=model_details.get("regularization", 1.0),
            max_iter=model_details.get("max_iterations", 100),
            random_state=42
        )
    elif selected_model == "RandomForestClassifier":
        model = RandomForestClassifier(
            n_estimators=model_details.get("max_trees", 100),
            max_depth=model_details.get("max_depth", None),
            min_samples_leaf=model_details.get("min_samples_per_leaf_max_value", 1),
            random_state=42
        )
    elif selected_model == "SVC":
        model = SVC(
            kernel=model_details.get("kernel", "rbf"),
            C=model_details.get("regularization", 1.0),
            random_state=42
        )
    elif selected_model == "DecisionTreeClassifier":
        model = DecisionTreeClassifier(
            max_depth=model_details.get("max_depth", None),
            min_samples_leaf=model_details.get("min_samples_per_leaf_max_value", 1),
            random_state=42
        )

elif prediction_type == "regression":
    if selected_model == "LinearRegression":
        model = LinearRegression()
    elif selected_model == "RandomForestRegressor":
        model = RandomForestRegressor(
            n_estimators=model_details.get("max_trees", 100),
            max_depth=model_details.get("max_depth", None),
            min_samples_leaf=model_details.get("min_samples_per_leaf_max_value", 1),
            random_state=42
        )
    elif selected_model == "SVR":
        model = SVR(
            kernel=model_details.get("kernel", "rbf"),
            C=model_details.get("regularization", 1.0)
        )
    elif selected_model == "DecisionTreeRegressor":
        model = DecisionTreeRegressor(
            max_depth=model_details.get("max_depth", None),
            min_samples_leaf=model_details.get("min_samples_per_leaf_max_value", 1),
            random_state=42
        )

print("Selected Model:", selected_model)
print("Model Object:", model)


# In[39]:


categorical_columns = X_train.select_dtypes(include=['object']).columns.tolist()
numeric_features = X.select_dtypes(include=["float64", "int64"]).columns


# In[42]:


preprocessor = ColumnTransformer(
    transformers=[
        ('num', StandardScaler(), X_train.select_dtypes(include=['float64', 'int64']).columns.tolist()),  
        ('cat', Pipeline([
            ('imputer', SimpleImputer(strategy='most_frequent')),  
            ('encoder', OneHotEncoder(handle_unknown='ignore'))  
        ]), categorical_columns)  
    ])


# In[50]:


pipeline = Pipeline([
    ("preprocessor", preprocessor),
    ("model", selected_model)
])


# In[51]:


print(selected_model)


# In[44]:


param_grid = {
    "model__n_estimators": [10, 20, 30],
    "model__max_depth": [5, 10, 15],
    "model__min_samples_split": [2, 5],
    "model__min_samples_leaf": [1, 2]
}


# In[45]:


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


# In[46]:


y_train


# In[63]:


pipeline = Pipeline([
    ("scaler", preprocessor),
    ("model", selected_model)
])


# In[65]:


#Q5)Hyper parameter tuning 
pipeline = Pipeline([
    ('preprocessor', preprocessor),
    ('model', RandomForestRegressor(random_state=42))  
])

param_grid = {
    "model__n_estimators": [10, 50, 100],          
    "model__max_depth": [5, 10, None],            
    "model__min_samples_split": [2, 5],           
    "model__min_samples_leaf": [1, 2, 4]          
}


grid_search = GridSearchCV(pipeline, param_grid, cv=3, scoring="r2", n_jobs=-1)
grid_search.fit(X_train, y_train)


y_pred = grid_search.best_estimator_.predict(X_test)
print("Best Parameters:", grid_search.best_params_)
print("R2 Score:", r2_score(y_test, y_pred))
print("MSE:", mean_squared_error(y_test, y_pred))


# In[62]:


print(pipeline.steps)


# In[66]:


print("Best Parameters:", grid_search.best_params_)

